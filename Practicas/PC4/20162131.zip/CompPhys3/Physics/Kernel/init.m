(* Wolfram Language Init File *)

Get[ "Physics`Electromagnetism`"]
Get[ "Physics`AnalysingData`"]
Get[ "Physics`QuantumMechanics`"]
Get[ "Physics`ClassicalMechanics`"]
Get[ "Physics`Integration`"]