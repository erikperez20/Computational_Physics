(* Wolfram Language Init File *)

Get[ "MathMethods`Functions`"]