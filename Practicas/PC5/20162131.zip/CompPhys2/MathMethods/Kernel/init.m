(* Wolfram Language Init File *)

Get[ "MathMethods`Functions`"]
Get[ "MathMethods`Interpolation`"]
Get[ "MathMethods`CPUArithmetic`"]
Get[ "MathMethods`NumericalFunctions`"]
Get[ "MathMethods`FindRoots`"]
Get[ "MathMethods`Differentiation`"]
Get[ "MathMethods`Integration`"]
Get[ "MathMethods`Fourier`"]
Get[ "MathMethods`ODE`"]