(* Wolfram Language Init File *)

Get[ "WLProgramming`Functional`"]
Get[ "WLProgramming`Structured`"]
Get[ "WLProgramming`RuleBased`"]