(* Wolfram Language Package *)

(* Created by the Wolfram Workbench 16 sep. 2021 *)

BeginPackage["Structured`"]
(* Exported symbols added here with SymbolName::usage *) 

sumNaturalsS::usage = "sumNaturalsS calcula la suma de 1 hasta n"
factorialS::usage = "factorialS calcula la productoria de n"
polynomialBaseS::usage = "polynomialBaseS calcula la base polinomial de orden n para la variable x"
reverseSublistsS::usage = "reverseSublistsS invierte el orden las sublistas dado una lista de listas"
removeSequentialRepetitionsS::usage = "removeSequentialRepetitionsS remueve las secuencias repetidas en una lista"
multiplyPolynomialsS::usage = "Multiplica dos polinomios y los expande"
apply::usage = "Funcion apply de forma estructural"
lispInterpreterS1::usage = "lisp interpreter version 1"
lispInterpreterS2::usage = "lisp interpreter version 2"

Begin["`Private`"]
(* Implementation of the package *)

sumNaturalsS[n_] := Module[{k, sum = 0},
	Do[sum = sum + k, {k, 1, n}]; sum]
	
factorialS[n_] := Module[{k, prod = 1},
  Do[prod = prod*k, {k, n}]; prod]

polynomialBaseS[n_, x_] := Module[{temp, list},
  temp = 1;
  list = {1};(*no mem allocation*)
  Do[AppendTo[list, temp = x*temp], {n}]; list]

reverseSublistsS[lista_] := 
 Module[{i, j, len, temp = lista}(*copy & mem alloc*),
  
  (*nested iteration form*)
  Do[
   len = Length[lista[[i]]];
   Do[
    temp[[i, j]] = lista[[i, len - j + 1]];
    temp[[i, len - j + 1]] = lista[[i, j]],
    {j, Floor[len/2]}], {i, 1, Length[lista]}]; temp]

removeSequentialRepetitionsS[lista_] :=
 Module[{newlist = {First[lista]}, elem},
  (*no alloc possible*)
  Do[
   (*Create list on the fly*)
   If[elem != Last[newlist],
    AppendTo[newlist, elem]],
   {elem, Rest[lista]}
   ];
  newlist
  ]

multiplyPolynomialsS[p1_, p2_, x_] := 
 Module[{product, pol1 = p1, pol2 = p2, i, elem},
  pol1[[0]] = List; (*Cambiar la cabecera del polinomio a una lista*)
  pol2[[0]] = List;
  product = {};
  Do[AppendTo[product, Times[i, j]], {i, pol1}, {j, pol2}];
  Total[product]
  ]

apply[op_,list_]:=
	Module[{temp = list},
		temp[[0]] = Sequence;
		op[temp]
	]

lispInterpreterS1:: notop = "`1` is not a valid operator.";

lispInterpreterS1[list_]:=
	Module[ {op = First[list], nums = Rest[list]},
	
		Which[
			op == "+",
				apply[Plus, nums],
			op == "-",
				apply[Subtract, nums],
			op == "*",
				apply[Times, nums],
			op == "/",
				apply[Divide, nums],
			True,
				Message[lispInterpreterS1::notop, op];
				$Failed
			]	
		] 

lispInterpreterS2:: notop = "`1` is not a valid operator.";

lispInterpreterS2[list_]:=
	Module[ {op = First[list], nums = Rest[list]},
	
		Switch[op,
			"+",
				apply[Plus, nums],
			"-",
				apply[Subtract, nums],
			"*",
				apply[Times, nums],
			"/",
				apply[Divide, nums],
			_,
				Message[lispInterpreterS2::notop, op];
				$Failed
			]	
		] 

End[]

EndPackage[]

