(* Wolfram Language Package *)

BeginPackage["Functional`"]
(* Exported symbols added here with SymbolName::usage *)  

sumNaturalsF::usage = "sumNaturalsF calcula la suma de 1 hasta n"
factorialF1::usage = "factorialF1 calcula la productoria de n"
factorialF2::usage = "factorialF2 retorna la lista de los factoriales de 1 hasta n"
polynomialBaseF::usage = "polynomialBaseF calcula la base polinomial de orden n para la variable x"
reverseSublistsF::usage = "reverseSublistsF invierte el orden las sublistas dado una lista de listas"
removeSequentialRepetitionsF::usage = "removeSequentialRepetitionsF remueve las secuencias repetidas en una lista"
multiplyPolynomialsF::usage = "Multiplica dos polinomios y los expande"

Begin["`Private`"] (* Begin Private Context *) 

sumNaturalsF[n_] := Plus @@ NestList[# + 1 &, 1, n - 1] (*Genera una lista de 1 a n con NestList y aplica Suma*)

factorialF1[n_] := Times @@ NestList[# + 1 &, 1, n - 1] (*Genera una lista de 1 a n con NestList y aplica Producto*)

factorialF2[n_] := (Times @@ NestList[# + 1 &, 1, # - 1]) & /@ NestList[# + 1 &, 1, n - 1] (*Genera una lista de 1 a n con NestList y aplica la productoria de cada elemento con Map*)

polynomialBaseF[n_, x_] := NestList[x # &, 1, n] (*NestList de los productos de x n veces*)

reverseSublistsF[lista_] := Reverse /@ lista (*Aplica Reverse a la lista con Map*)

removeSequentialRepetitionsF[lista_] := lista //. {x___, y_, z_, w___} /; y == z :> {x, y, w} (*busca patrones repetidos y elimina la repeticion secuencialmente*)

multiplyPolynomialsF[p1_, p2_, x_] := Outer[Times, p1, p2] (*Aplica Outer con operador Times para multiplicar ambos polinomios*)

End[] (* End Private Context *)

EndPackage[]