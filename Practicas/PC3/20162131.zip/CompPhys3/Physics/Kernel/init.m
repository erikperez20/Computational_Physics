(* Wolfram Language Init File *)

Get[ "Physics`Electromagnetism`"]